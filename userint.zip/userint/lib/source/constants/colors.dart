import 'package:flutter/material.dart';

//const IPrimaryColor = Color(0xFFFFE400);
const IPrimaryColor = Color(0xFFE1F5FE);
const ISecondaryColor = Color(0xFF272727);
const IAccentColor = Color(0xFF001BFF);

const ICardColor = Color(0xFFF7F6F1);
const IWhiteColor = Color(0xffffffff);
const IDarkColor = Color(0xFF000000);

///list of on boarding colors :-
const IOnBoardingPage1Color = Colors.white;
const IOnBoardingPage2Color = Color(0xfffddcdf);
const IOnBoardingPage3Color = Color(0xffffdcbd);
