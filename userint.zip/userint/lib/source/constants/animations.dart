///welcome
const String IWelcomeAnimation = "assets/animations/wel.json";
const String ILoginAnimation = "assets/animations/login.json";

///signup animation
const String ISignUpAnimation = "assets/animations/signuupani.json";

///forget pass animation
const String IForgetPassAnimation = "assets/animations/forgotpassword.json";
const String IForgetPassPhoneAnimation = "assets/animations/forgotpassphone.json";
