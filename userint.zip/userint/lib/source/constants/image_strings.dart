
const String ISplashTopIcon = "assets/images/multitask.png";
const String ISplashImage = "assets/images/multitask2.png";
const String ISplashImageBottomLeft = "assets/images/multitask3.png";

///on boarding Images
const String IOnBoardingImage1 = "assets/images/on_boarding_images/pageoneimage.jpg";
const String IOnBoardingImage2 = "assets/images/on_boarding_images/two.jpg";
const String IOnBoardingImage3 = "assets/images/on_boarding_images/pageoneimage.jpg";

///welcome screen images
const String IWelcomeScreenImage = "assets/images/welcome_images/welcome_screen_image.jpg";

///login screen images
const String ILoginScreenImaage = "assets/images/login_images/login.png";
// const String ILoginScreenLogo = "assets/images/login_images/logo.jpg";
// const String GoogleLogo = "assets/images/login_images/google_logo.png";
const String GoggleLog = "assets/images/login_images/glogo.png";