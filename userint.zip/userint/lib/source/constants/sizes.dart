
//app default sizes
const IDefaultSize = 30.0 ;
const ISplashContainerSize = 50.0 ;

///welcome_screen
const IButtonHeight = 18.0 ;
///login screen
 const IFormHeight =30.0 ;

