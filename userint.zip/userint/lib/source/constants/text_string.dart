//text string

const String IAppName = "MULTI-TASK";
const String IAppTagLine = "All At One Place ";

///On Boarding Text
const String IOnBoardingTitle1 = "IOnBoardingTitle1 ";
const String IOnBoardingTitle2 = "IOnBoardingTitle2";
const String IOnBoardingTitle3 = "IOnBoardingTitle3";
const String IOnBoardingSubTitle1 = "IOnBoardingSubTitle1";
const String IOnBoardingSubTitle2 = "IOnBoardingSubTitle2";
const String IOnBoardingSubTitle3 = "IOnBoardingSubTitle3";
const String IOnBoardingCounter1 = "1/3";
const String IOnBoardingCounter2 = "2/3";
const String IOnBoardingCounter3 = "3/3";

///welcome screen texts
const String IWelcomeScreenTitle ="Faster & Smarter";
const String IwelcomeScreenSubTitle = "Making your experience way better ";
const String ILogin ="Login";
const String ISignUp ="Sign-Up";
const String IAboutUsText ="About Us";

///Login Screen Texts
const String ILoginScreenTitle = "Welcome Back ";
const String ILoginScreenSubTitle = "Make it work , make it right , make it fast ";
const String IEmail = "E-mail" ;
const String IPassword = "password";
const String IForgetPassword= "Forget Password?";
const String ISignInWithGoogle ="Sign-In with Google";
const String IDontHaveAnAccount =" Don't have an Account ?  ";
const String ISignUptext ="SignUp";

///SignUp screen Texts
const String ISignUpTitle = "Sign-Up";
const String ISignUpSubTitle = "Create your profile here";
const String IRememberMe = "Remember Me ?";
const String IAlreadyHaveAnAccount = "Already have an Account   ";
const String IFullName = "Full Name ";
const String IEmailsignup ="E-mail";
const String IPasswordSignup = "Password";
const String IPhnNoSignup = "Phone-Number";

///forget password texts
const String IForgetpassTitle ="Make a Selection";
const String IForgetpassSubTitle = "Select one of the options given below to reset your password.";
const String IResetViaEmail = "Reset via E-mail Verification";
const String IResetViaPhone = "Reset via Phone Verification";
const String IPhnNoforget = "Phone Number";
const String IForgetPasswordText ="Forget Password";

///forget password via phone
const String IForgetPhoneSubTitle ="Enter your registered Phone Number to receive OTP";
const String IForgetPasswordTxtSubPhone ="Enter Phone Number to receive OTP ";
///forget password via E-mail
const String IForgetMailSubTitle = "Enter the registered E-Mail to receive OTP ";
const String IForgetPasswordTxt ="Forget Password";
const String IForgetPasswordTxtSub ="Enter Email to receive OTP ";
const String INext ="Next" ;
const String IPhoneTxt = "Phone Number";

///otp screen texts
const String IOtpTitle = "One Time Password";
const String IOtpSubTitle = "Verification";
const String IOtpMessage = "Enter the Verification code sent at ";



