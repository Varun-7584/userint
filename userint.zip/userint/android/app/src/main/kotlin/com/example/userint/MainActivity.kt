package com.example.userint

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
